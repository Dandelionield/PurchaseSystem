DROP SEQUENCE authors_seq;
CREATE SEQUENCE authors_seq START WITH 100;

DROP SEQUENCE books_seq;
CREATE SEQUENCE books_seq START WITH 100;

DROP SEQUENCE venues_seq;
CREATE SEQUENCE venues_seq START WITH 100;

DROP SEQUENCE events_seq;
CREATE SEQUENCE events_seq START WITH 100;

DROP SEQUENCE hosts_seq;
CREATE SEQUENCE hosts_seq START WITH 100;

DROP SEQUENCE employees_seq;
CREATE SEQUENCE employees_seq START WITH 100;

DROP SEQUENCE positions_seq;
CREATE SEQUENCE positions_seq START WITH 100;

DROP SEQUENCE awesome_people_seq;
CREATE SEQUENCE awesome_people_seq START WITH 100;

DROP SEQUENCE amenities_seq;
CREATE SEQUENCE amenities_seq START WITH 100;

DROP SEQUENCE property_seq;
CREATE SEQUENCE property_seq START WITH 100;

DROP SEQUENCE property_amenities_seq;
CREATE SEQUENCE property_amenities_seq START WITH 100;

DROP SEQUENCE valuestore_seq;
CREATE SEQUENCE valuestore_seq START WITH 100;
